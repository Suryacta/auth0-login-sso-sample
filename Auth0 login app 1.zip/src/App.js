import './App.css';
import { useAuth0 } from '@auth0/auth0-react'

import LoginButton from './LoginButton';
import LogOutButton from './LogOutButton';
import Profile from './Profile';
// import {BrowserRouter, Route, Routes} from 'react-router-dom';

function App() {
  const{ user, isAuthenticated, isLoading } = useAuth0();
  console.log(user, isAuthenticated, isLoading);
  return (
    <div className="App">
     <LoginButton/>
     <LogOutButton/>
     <Profile/>
     
    </div>
  );
}

export default App;
