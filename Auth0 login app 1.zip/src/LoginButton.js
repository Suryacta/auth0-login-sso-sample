import React from 'react'
import { useAuth0 } from '@auth0/auth0-react'
import styled from 'styled-components';

const StyledLogin = styled.div`
.login{
    margin-top: 10%;
}
`

const LoginButton = () => {
    const { loginWithRedirect, isAuthenticated } = useAuth0();
  return (
    isAuthenticated && (
      <StyledLogin>
        
    <div className='login'>
        <button onClick={()=> loginWithRedirect()}>Login</button>
    </div>
    
    </StyledLogin>
  )
  )
}

export default LoginButton