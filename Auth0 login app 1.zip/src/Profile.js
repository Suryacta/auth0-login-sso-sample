import { useAuth0 } from '@auth0/auth0-react'
import React from 'react'

const Profile = async() => {
    const{ user, isAuthenticated, isLoading, getAccessTokenWithPopup } = useAuth0();

    const domain = "dev-pv8obna4.us.auth0.com";

    const access = await getAccessTokenWithPopup({
      audience: `https://${domain}/api/v2/`,
          scope: "read:current_user"
    });

    console.log(access);
    
    if(isLoading){
        return <div>...Loading</div>
    }
    console.log(user, isAuthenticated, isLoading, getAccessTokenWithPopup);
  return (
    <div>
     { isAuthenticated && 
        <div className='profile'>
          <img src={user.picture} alt={user.name}/>
          <p>Welcome {user.name}</p>
          <p>{user.email}</p>
        </div>
       }
       </div>
  )
}

export default Profile