import React from 'react'

function Unauthorized() {
  return (
    <div className='unauthorized'>
       <h1> Unauthorized error. 404 not found.</h1>

    </div>
  )
}

export default Unauthorized