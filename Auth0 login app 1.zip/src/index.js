import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import { Auth0Provider } from '@auth0/auth0-react';
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import Unauthorized from './Unauthorized';

ReactDOM.render(
  <Auth0Provider
  
    domain='dev-pv8obna4.us.auth0.com'
    clientId='VmcZMa1WRaAcahXiGe7JPKnr3IMaHzSb'
    
    redirectUri='http://localhost:3000'
  >
    <App /> 
    <a href='http://localhost:3001' rel='noreferrer' target='_blank'>click</a>
  </Auth0Provider>,
  document.getElementById('root')
);
