
import './App.css';
import Profile from './Profile';

import './App.css';
import {ApolloClient, 

        InMemoryCache, 
        ApolloProvider, 
        HttpLink, 
        from} from "@apollo/client";

import {onError} from '@apollo/client/link/error';
import GetUsers from './Components/GetUsers';
import SignButton from './Signin';

const errorLink = onError(({graphqlErrors, networkErrors}) =>{
  if(graphqlErrors){
    graphqlErrors.map(({message, location, path}) => { 
        return alert(message);
    });
  }
})

const link = from([
  errorLink,
  new HttpLink({uri: "https://rickandmortyapi.com/graphql"}),

])


const client = new ApolloClient({
  cache: new InMemoryCache(),
  link: link
})
function App() {
  return (
    <div>
      
    <Profile/>
    
   
    <ApolloProvider client={client}>
    <SignButton/>
        <GetUsers/>
    </ApolloProvider>
    </div>
  );
}

export default App;




