import React, {useEffect} from 'react'
import{ useQuery} from "@apollo/client";
import {LOAD_USERS} from '../GraphQL/Query'

function GetUsers() {
    const {error, data}  = useQuery(LOAD_USERS)
    //  const [users, setUsers] = useState([])

    useEffect(() => {
        console.log(data)
        // setUsers(data.characters.results);
        
    }, [data, error])

  return (
    <div>
    
         {/* {users.map((val) =>(
             <h1>{val.data.characters.results}</h1>  
        ))}  */}
    </div>
  )
}

export default GetUsers