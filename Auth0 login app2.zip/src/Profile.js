import React, { useEffect, useState } from "react";
import { useAuth0 } from "@auth0/auth0-react";

const Profile = () => {
  const { user, isAuthenticated, getAccessTokenWithPopup } = useAuth0();
  const [userMetadata, setUserMetadata] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const[display, setDisplay]= useState(true);
 
  useEffect(() => {
    const getUserMetadata = async () => {
      const domain = "dev-pv8obna4.us.auth0.com";
  
      try {
        const accessToken = await getAccessTokenWithPopup({
          
          audience: `https://${domain}/api/v2/`,
          scope: "read:current_user"
          
        });
        console.log(accessToken);
        const userDetailsByIdUrl = `https://${domain}/api/v2/user${user.sub}`;
  
        const metadataResponse = await fetch(userDetailsByIdUrl, {
          prompt: 'consent',
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        });
  
        const { user_metadata } = await metadataResponse.json();
  
        setUserMetadata({...user_metadata});
      } catch (e) {
        console.log(e.message);
      }
    };
  
    getUserMetadata();
  
  }, [getAccessTokenWithPopup, user?.sub]);

  console.log(userMetadata);
  
  return (
    <>
    {isAuthenticated && 
    <>
   { display && <button onClick={()=> {
     setDisplay(false)
     setIsOpen(true) }}>signin</button>}{
      isOpen &&
      <div>
      <img src={user.picture} alt={user.name} />
      <h2>{user.name}</h2>
      <p>{user.email}</p>
    </div>
    }
      
    </>}
      

      
      
      </>
    
  );
};

export default Profile;