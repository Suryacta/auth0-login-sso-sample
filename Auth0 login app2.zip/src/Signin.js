import React from 'react'
import { useAuth0 } from '@auth0/auth0-react'
import styled from 'styled-components';

const StyledLogin = styled.div`
.login{
    margin-top: 10%;
}
`

const SignButton = () => {
    const { loginWithRedirect, isAuthenticated } = useAuth0();
  return (
    !isAuthenticated && (
      <StyledLogin>
        
    <div className='login'>
        <button onClick={()=> loginWithRedirect()}>Signin</button>
    </div>
    
    </StyledLogin>
  )
  )
}

export default SignButton